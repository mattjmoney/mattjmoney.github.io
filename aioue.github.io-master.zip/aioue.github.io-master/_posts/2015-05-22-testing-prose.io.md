---
layout: post
title: Testing Prose.io
date: '2015-05-22 11:18:52'
---

Basic, WYSIWYG markdown editor.

Prose.io has a pretty nasty permission requirement by default. Access to all your repositories, public and private.

![allow ALL THE REPOS](http://i.imgur.com/tmdfrpX.jpg)

[Fix it by editing the gitub authorize URL to allow public access only](https://github.com/prose/prose/issues/126#issuecomment-65861724).
