---
layout: post
title: Start a simple http server with python
date: '2015-05-23 00:05:04'
---

`python -mSimpleHTTPServer`

Starts serving a site from the current directory on port `8000` with directory listing activated.

Accessible from http://127.0.0.1:8000
